import React from 'react';
import './Portfolio.css';

function Portfolio() {
  return (
    <div className="portfolio">
    <header className="header">
      <div className="overlay">
        <div className="container">
            <div className="profile-picture">
              <img src= {require('./Ami.JPG')}/>
            </div>
          <div className="name-box">
            <div className="red-rectangle">
              <p>This is Sheehan's Portfolio!</p>
            </div>
          </div>
          <h1 className="portfolio-title">Web Developer</h1>
        </div>
      </div>
      </header>
      <section className="about">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h2>About Me</h2>
              <p>
                I am Sheehan Nag Chowdhury. I'm a passionate web developer with a strong focus on creating beautiful and functional web applications. My goal is to make the web a better place.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="projects">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="project">
                <h3>Weather Application</h3>
                <p>A weather website/web-based platform that provides users with real-time and historical weather data for cities across the world</p>
                <br></br>
                <a href=" https://sheehannc.github.io/WebD_project/" className="btn btn-primary" target="_blank" rel="noopener noreferrer">View Project</a>
              </div>
            </div>
            <div className="col-md-4">
              <div className="project">
                <h3>Women Empowerment Advertisement </h3>
                <p>An advertisement for Mukti NGO, Sundarbans about Women Empowerment which was used to raise Rs 27,000 for the cause</p>
                <br></br>
                <a href="https://www.instagram.com/p/Cn1D9a1PnpI/?igshid=MTIyMzRjYmRlZg==" className="btn btn-primary" target="_blank" rel="noopener noreferrer">View Project</a>
              </div>
            </div>
            {/* Add more project items as needed */}
          </div>
        </div>
      </section>
      <section className="contact">
        <div className="container">
          <h2>Contact Me</h2>
          <p>You can reach me at: enceesheehan@email.com</p>
        </div>
      </section>
    </div>
  );
}

export default Portfolio;
